import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    int Num;
    boolean again = true;
    Scanner scan = new Scanner(System.in);
    Box b1 = new Box();
    // b1.l = 11.3;
    Pyramid p1 = new Pyramid();
    Sphere s1 = new Sphere();
    double val = 0.0;
    while (again) {
      System.out.println("Welcome to Shape Tester!");
      System.out.println("Enter 1 for box:");
      System.out.println("Enter 2 for Pyramid:");
      System.out.println("Enter 3 for Sphere:");
      Num = scan.nextInt();

      if (Num == 1) {
        System.out.println("Please enter box length:");
        val = scan.nextDouble();
        b1.setL(val);

        System.out.println("Please enter box width:");
        val = scan.nextInt();
        b1.setW(val);

        System.out.println("Please enter box height:");
        val = scan.nextInt();
        b1.setH(val);

        System.out.println("Volume: " + b1.calcVol());
        System.out.println("Surface Area:" + b1.calcSurfArea());
        System.out.println("Enter 4 if you want to go again:");
        Num = scan.nextInt();
      } else if (Num == 2) {
        System.out.println("Please enter Pyramid length:");
        val = scan.nextDouble();
        p1.setL(val);

        System.out.println("Please enter Pyramid width:");
        val = scan.nextInt();
        p1.setW(val);

        System.out.println("Please enter Pyramid height:");
        val = scan.nextInt();
        p1.setH(val);

        System.out.println("Volume: " + p1.calcVol());
        System.out.println("Surface Area:" + p1.calcSurfArea());
        System.out.println("Enter 4 if you want to go again:");
        Num = scan.nextInt();
      } else if (Num == 3) {
        System.out.println("Please enter Sphere radius:");
        val = scan.nextDouble();
        s1.setR(val);

        System.out.println("Volume: " + s1.calcVol());
        System.out.println("Surface Area:" + s1.calcSurfArea());
        System.out.println("Enter 4 to quit");
        Num = scan.nextInt();
      } else if (Num == 4) {
        again = false;
        scan.close();
      }
    }
  }
}
